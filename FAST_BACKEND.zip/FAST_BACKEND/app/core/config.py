import os
from typing import List
import sys

from dotenv import load_dotenv
from pydantic import BaseSettings

load_dotenv()

ENV: str = ""


class Configs(BaseSettings):
    # baseos.environ["TEST_ENV_VAR"]
    ENV: str = os.getenv("ENV", "dev")
    API: str = "/api"
    API_V1_STR: str = "/api/v1"
    API_V2_STR: str = "/api/v2"
    PROJECT_NAME: str = "Data Center Sustainability"
    ENV_DATABASE_MAPPER: dict = {
        "prod": "fca",
        "stage": "stage-fca",
        #"dev": "DCS_DB",
        "dev": "dcs_db", # for local development ahmed laptop
        "test": "test-fca",
    }
    DB_ENGINE_MAPPER: dict = {
        "postgresql": "postgresql",
        "mysql": "mysql+pymysql",
    }

    PROJECT_ROOT: str = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

    # date
    DATETIME_FORMAT: str = "%Y-%m-%dT%H:%M:%S"
    DATE_FORMAT: str = "%Y-%m-%d"

    # auth
    SECRET_KEY: str = os.getenv("SECRET_KEY", "")
    # 60 minutes * 24 hours * 30 days = 30 days
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 30

    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["*"]

    # mysql
    DB: str = os.getenv("DB", "mysql")
    DB_USER: str = os.getenv("DB_USER")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD")
    DB_HOST: str = os.getenv("DB_HOST")
    DB_PORT: str = os.getenv("DB_PORT", "3306")
    DB_ENGINE: str = DB_ENGINE_MAPPER.get(DB, "mysql+pymysql")

    # TimescaleDB
    TIMESCALEDB_URL: str = os.getenv("TIMESCALEDB_URL", "127.0.0.1")
    TIMESCALEDB_USER: str = os.getenv("TIMESCALEDB_USER", "postgres")
    TIMESCALEDB_PASSWORD: str = os.getenv("TIMESCALEDB_PASSWORD", "password")
    TIMESCALEDB_DB: str = os.getenv("TIMESCALEDB_DB", "postgres")
    TIMESCALEDB_PORT: str = os.getenv("TIMESCALEDB_PORT", "5433")
    TIMESCALEDB_ENGINE: str = "postgresql"

    # influxdb
    INFLUXDB_URL: str = os.getenv("INFLUXDB_URL")
    INFLUXDB_TOKEN: str = os.getenv("INFLUXDB_TOKEN")
    INFLUXDB_ORG: str = os.getenv("INFLUXDB_ORG")
    INFLUXDB_BUCKET: str = os.getenv("INFLUXDB_BUCKET")
    print("Influxdb url in config", INFLUXDB_URL, file=sys.stderr)
    print("Influxdb token in config", INFLUXDB_TOKEN, file=sys.stderr)
    print("Influxdb org in config", INFLUXDB_ORG, file=sys.stderr)
    print("Influxdb bucket in config", INFLUXDB_BUCKET, file=sys.stderr)

    # openai
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY")

    DATABASE_URI_FORMAT: str = "{db_engine}://{user}:{password}@{host}:{port}/{database}"

    DATABASE_URI = "{db_engine}://{user}:{password}@{host}:{port}/{database}".format(
        db_engine=DB_ENGINE,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT,
        database=ENV_DATABASE_MAPPER[ENV],
    )
    print("MYSQL Database url in config", DATABASE_URI, file=sys.stderr)

    TIMESCALEDB_URI: str = "{engine}://{user}:{password}@{host}:{port}/{db}".format(
        engine=TIMESCALEDB_ENGINE,
        user=TIMESCALEDB_USER,
        password=TIMESCALEDB_PASSWORD,
        host=TIMESCALEDB_URL,
        port=TIMESCALEDB_PORT,
        db=TIMESCALEDB_DB,
    )
    print("TimescaleDB URI in config:", TIMESCALEDB_URI, file=sys.stderr)


    # find query
    PAGE = 1
    PAGE_SIZE = 20
    ORDERING = "-id"

    class Config:
        case_sensitive = True


class TestConfigs(Configs):
    ENV: str = "test"


configs = Configs()

if ENV == "prod":
    pass
elif ENV == "stage":
    pass
elif ENV == "test":
    setting = TestConfigs()
