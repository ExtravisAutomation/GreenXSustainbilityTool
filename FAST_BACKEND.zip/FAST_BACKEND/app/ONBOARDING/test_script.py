import logging
import os

logging.basicConfig(level=logging.INFO)
logging.info(f"Test script running from {os.getcwd()}")