import logging
import os

logging.basicConfig(level=logging.INFO)
logging.info(f"Test script running from {os.getcwd()}")
print("Test file executed")


def main():
    print("TESTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTt")


if __name__=="__main__":
    main()
