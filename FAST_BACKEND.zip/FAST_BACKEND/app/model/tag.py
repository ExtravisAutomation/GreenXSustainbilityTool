# from sqlalchemy import Column, String
# from .base_model import BaseModel
#
# class Tag(BaseModel):
#     __tablename__ = "tag"
#
#     user_token = Column(String)
#     name = Column(String, unique=True, index=True)
#     description = Column(String, default=None, nullable=True)
