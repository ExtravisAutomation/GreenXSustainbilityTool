# from sqlalchemy import Column, String, Boolean, ForeignKey
# from .base_model import BaseModel
#
#
# class Post(BaseModel):
#     __tablename__ = "posts"
#
#     user_token = Column(String)
#     title = Column(String, default=None, nullable=True)
#     content = Column(String, default=None, nullable=True)
#     is_published = Column(Boolean, default=False)
